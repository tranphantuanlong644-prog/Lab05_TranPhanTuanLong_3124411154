namespace BaiNangCao_XuLyChuoi;

public class InputDialog : Form
{
    private readonly TextBox txtGiaTri = new();

    public string GiaTri => txtGiaTri.Text.Trim();

    public InputDialog(string tieuDe, string noiDung, string giaTriBanDau)
    {
        Text = tieuDe;
        StartPosition = FormStartPosition.CenterParent;
        ClientSize = new Size(470, 170);
        Font = new Font("Tahoma", 10.5F);
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;
        MinimizeBox = false;
        ShowInTaskbar = false;

        Label lblNoiDung = new()
        {
            Text = noiDung,
            AutoSize = true,
            Location = new Point(25, 24)
        };

        txtGiaTri.Location = new Point(25, 57);
        txtGiaTri.Size = new Size(415, 29);
        txtGiaTri.Text = giaTriBanDau;
        txtGiaTri.SelectAll();

        Button btnDongY = new()
        {
            Text = "Đồng ý",
            DialogResult = DialogResult.OK,
            Location = new Point(220, 110),
            Size = new Size(100, 36)
        };

        Button btnHuy = new()
        {
            Text = "Hủy",
            DialogResult = DialogResult.Cancel,
            Location = new Point(340, 110),
            Size = new Size(100, 36)
        };

        AcceptButton = btnDongY;
        CancelButton = btnHuy;
        Controls.AddRange(new Control[] { lblNoiDung, txtGiaTri, btnDongY, btnHuy });
    }
}
