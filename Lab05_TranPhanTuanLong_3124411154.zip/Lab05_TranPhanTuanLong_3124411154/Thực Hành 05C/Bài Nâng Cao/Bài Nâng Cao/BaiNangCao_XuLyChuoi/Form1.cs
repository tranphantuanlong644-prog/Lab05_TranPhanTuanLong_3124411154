using System.Globalization;
using System.Text;

namespace BaiNangCao_XuLyChuoi;

/// <summary>
/// Quản lý danh sách họ tên: tạo dữ liệu không trùng, lọc, sắp xếp, chuẩn hóa, chỉnh sửa và thống kê.
/// </summary>
public class Form1 : Form
{
    private readonly ListBox lstHoTen = new();
    private readonly TextBox txtTimKiem = new();
    private readonly Label lblThongKe = new();
    private readonly Random random = new();

    private readonly string[] HO =
    {
        "Lê", "Nguyễn", "Lý", "Trần", "Lâm", "Hồ", "Lai", "Huỳnh", "La"
    };

    private readonly string[] TENLOT =
    {
        "Quang", "Thành", "Ngọc", "Anh", "Xuân", "Bảo",
        "Cẩm", "Thị", "Kim", "Thái", "Hồng"
    };

    private readonly string[] TEN =
    {
        "Hà", "Danh", "Sơn", "Mai", "Thắng", "Kỳ",
        "Thành", "Lâm", "Tâm", "Phụng", "Thắm"
    };

    public Form1()
    {
        KhoiTaoGiaoDien();
    }

    private void KhoiTaoGiaoDien()
    {
        Text = "Bài nâng cao - Xử lý chuỗi họ tên";
        StartPosition = FormStartPosition.CenterScreen;
        ClientSize = new Size(940, 675);
        Font = new Font("Tahoma", 11F);
        FormBorderStyle = FormBorderStyle.FixedSingle;
        MaximizeBox = false;

        Label lblTieuDe = new()
        {
            Text = "XỬ LÝ DANH SÁCH HỌ TÊN",
            Font = new Font("Tahoma", 20F, FontStyle.Bold),
            ForeColor = Color.DarkBlue,
            AutoSize = true,
            Location = new Point(240, 22)
        };

        Label lblTim = new()
        {
            Text = "Tìm kiếm:",
            AutoSize = true,
            Location = new Point(40, 92)
        };

        txtTimKiem.Location = new Point(145, 87);
        txtTimKiem.Size = new Size(355, 30);
        txtTimKiem.PlaceholderText = "Nhập họ, tên lót hoặc tên cần tìm...";
        txtTimKiem.TextChanged += (_, _) => LocDanhSach();

        Button btnXoaTim = TaoButton("Xóa tìm", 520, 84, 110, 38);
        btnXoaTim.Click += (_, _) => txtTimKiem.Clear();

        lstHoTen.Location = new Point(40, 140);
        lstHoTen.Size = new Size(510, 440);
        lstHoTen.SelectionMode = SelectionMode.MultiExtended;
        lstHoTen.DoubleClick += lstHoTen_DoubleClick;
        lstHoTen.SelectedIndexChanged += (_, _) => CapNhatThongKe();

        GroupBox grpChucNang = new()
        {
            Text = "Chức năng",
            Location = new Point(585, 140),
            Size = new Size(310, 440)
        };

        Button btnNgauNhien = TaoButton("&Ngẫu nhiên 50 tên", 25, 42, 260, 40);
        Button btnSapXepAZ = TaoButton("Sắp xếp &A - Z", 25, 94, 260, 40);
        Button btnSapXepZA = TaoButton("Sắp xếp &Z - A", 25, 146, 260, 40);
        Button btnChuanHoa = TaoButton("&Chuẩn hóa họ tên", 25, 198, 260, 40);
        Button btnXoaChon = TaoButton("&Xóa tên đang chọn", 25, 250, 260, 40);
        Button btnXoaTatCa = TaoButton("Xóa &tất cả", 25, 302, 260, 40);
        Button btnThongKe = TaoButton("&Thống kê danh sách", 25, 354, 260, 40);

        btnNgauNhien.Click += (_, _) => TaoDanhSachNgauNhien();
        btnSapXepAZ.Click += (_, _) => SapXep(false);
        btnSapXepZA.Click += (_, _) => SapXep(true);
        btnChuanHoa.Click += (_, _) => ChuanHoaDanhSach();
        btnXoaChon.Click += (_, _) => XoaTenDangChon();
        btnXoaTatCa.Click += (_, _) => XoaTatCa();
        btnThongKe.Click += (_, _) => HienThiThongKe();

        grpChucNang.Controls.AddRange(new Control[]
        {
            btnNgauNhien, btnSapXepAZ, btnSapXepZA, btnChuanHoa,
            btnXoaChon, btnXoaTatCa, btnThongKe
        });

        lblThongKe.AutoSize = true;
        lblThongKe.Font = new Font("Tahoma", 10.5F, FontStyle.Bold);
        lblThongKe.ForeColor = Color.DarkGreen;
        lblThongKe.Location = new Point(40, 604);
        lblThongKe.Text = "Tổng số tên: 0";

        Label lblGoiY = new()
        {
            Text = "Gợi ý: Double-click vào một tên để chỉnh sửa.",
            AutoSize = true,
            ForeColor = Color.DarkRed,
            Location = new Point(390, 604)
        };

        Button btnThoat = TaoButton("Th&oát", 775, 606, 120, 40);
        btnThoat.Click += (_, _) => Close();

        Controls.AddRange(new Control[]
        {
            lblTieuDe, lblTim, txtTimKiem, btnXoaTim, lstHoTen,
            grpChucNang, lblThongKe, lblGoiY, btnThoat
        });

        FormClosing += Form1_FormClosing;
    }

    private Button TaoButton(string text, int x, int y, int width, int height)
    {
        return new Button
        {
            Text = text,
            Location = new Point(x, y),
            Size = new Size(width, height),
            UseVisualStyleBackColor = true
        };
    }

    private void TaoDanhSachNgauNhien()
    {
        lstHoTen.Items.Clear();

        while (lstHoTen.Items.Count < 50)
        {
            string hoTen = $"{HO[random.Next(HO.Length)]} " +
                           $"{TENLOT[random.Next(TENLOT.Length)]} " +
                           $"{TEN[random.Next(TEN.Length)]}";

            if (!lstHoTen.Items.Cast<string>()
                .Any(x => x.Equals(hoTen, StringComparison.OrdinalIgnoreCase)))
            {
                lstHoTen.Items.Add(hoTen);
            }
        }

        CapNhatThongKe();
    }

    private void SapXep(bool giamDan)
    {
        if (!KiemTraCoDuLieu()) return;

        IEnumerable<string> duLieu = lstHoTen.Items.Cast<string>();
        duLieu = giamDan
            ? duLieu.OrderByDescending(x => BoDau(x))
            : duLieu.OrderBy(x => BoDau(x));

        GanLaiDanhSach(duLieu);
    }

    private void ChuanHoaDanhSach()
    {
        if (!KiemTraCoDuLieu()) return;

        List<string> ketQua = lstHoTen.Items.Cast<string>()
            .Select(ChuanHoaHoTen)
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToList();

        GanLaiDanhSach(ketQua);
    }

    private string ChuanHoaHoTen(string hoTen)
    {
        TextInfo textInfo = new CultureInfo("vi-VN", false).TextInfo;
        string rutGon = string.Join(" ", hoTen
            .Trim()
            .Split(' ', StringSplitOptions.RemoveEmptyEntries));

        return textInfo.ToTitleCase(rutGon.ToLower());
    }

    private void XoaTenDangChon()
    {
        if (lstHoTen.SelectedIndices.Count == 0)
        {
            MessageBox.Show(
                "Vui lòng chọn ít nhất một tên cần xóa.",
                "Thông báo",
                MessageBoxButtons.OK,
                MessageBoxIcon.Warning);
            return;
        }

        DialogResult ketQua = MessageBox.Show(
            $"Bạn có chắc muốn xóa {lstHoTen.SelectedIndices.Count} tên đang chọn?",
            "Xác nhận xóa",
            MessageBoxButtons.YesNo,
            MessageBoxIcon.Question,
            MessageBoxDefaultButton.Button2);

        if (ketQua != DialogResult.Yes) return;

        for (int i = lstHoTen.SelectedIndices.Count - 1; i >= 0; i--)
            lstHoTen.Items.RemoveAt(lstHoTen.SelectedIndices[i]);

        CapNhatThongKe();
    }

    private void XoaTatCa()
    {
        if (!KiemTraCoDuLieu()) return;

        if (MessageBox.Show(
            "Bạn có chắc muốn xóa toàn bộ danh sách?",
            "Xác nhận",
            MessageBoxButtons.YesNo,
            MessageBoxIcon.Question,
            MessageBoxDefaultButton.Button2) == DialogResult.Yes)
        {
            lstHoTen.Items.Clear();
            CapNhatThongKe();
        }
    }

    private void HienThiThongKe()
    {
        if (!KiemTraCoDuLieu()) return;

        var danhSach = lstHoTen.Items.Cast<string>().ToList();
        string tenDaiNhat = danhSach.OrderByDescending(x => x.Length).First();
        string tenNganNhat = danhSach.OrderBy(x => x.Length).First();
        int soHoNguyen = danhSach.Count(x => x.StartsWith("Nguyễn ", StringComparison.OrdinalIgnoreCase));

        MessageBox.Show(
            $"Tổng số họ tên: {danhSach.Count}\n" +
            $"Tên dài nhất: {tenDaiNhat}\n" +
            $"Tên ngắn nhất: {tenNganNhat}\n" +
            $"Số người họ Nguyễn: {soHoNguyen}",
            "Thống kê danh sách",
            MessageBoxButtons.OK,
            MessageBoxIcon.Information);
    }

    private void lstHoTen_DoubleClick(object sender, EventArgs e)
    {
        if (lstHoTen.SelectedIndex < 0) return;

        int viTri = lstHoTen.SelectedIndex;
        string tenCu = lstHoTen.SelectedItem.ToString();

        using InputDialog hopThoai = new(
            "Chỉnh sửa họ tên",
            "Nhập họ tên mới:",
            tenCu);

        if (hopThoai.ShowDialog(this) != DialogResult.OK) return;

        string tenMoi = ChuanHoaHoTen(hopThoai.GiaTri);

        if (string.IsNullOrWhiteSpace(tenMoi))
        {
            MessageBox.Show("Họ tên mới không được để trống.");
            return;
        }

        bool biTrung = lstHoTen.Items.Cast<string>()
            .Where((_, index) => index != viTri)
            .Any(x => x.Equals(tenMoi, StringComparison.OrdinalIgnoreCase));

        if (biTrung)
        {
            MessageBox.Show("Họ tên mới đã tồn tại trong danh sách.");
            return;
        }

        lstHoTen.Items[viTri] = tenMoi;
        lstHoTen.SelectedIndex = viTri;
        CapNhatThongKe();
    }

    private void LocDanhSach()
    {
        string tuKhoa = BoDau(txtTimKiem.Text.Trim());

        for (int i = 0; i < lstHoTen.Items.Count; i++)
        {
            string hoTen = BoDau(lstHoTen.Items[i].ToString());
            lstHoTen.SetSelected(
                i,
                !string.IsNullOrWhiteSpace(tuKhoa) &&
                hoTen.Contains(tuKhoa, StringComparison.OrdinalIgnoreCase));
        }

        CapNhatThongKe();
    }

    private string BoDau(string chuoi)
    {
        string chuanHoa = chuoi.Normalize(NormalizationForm.FormD);

        return string.Concat(chuanHoa.Where(c =>
            CharUnicodeInfo.GetUnicodeCategory(c) != UnicodeCategory.NonSpacingMark))
            .Normalize(NormalizationForm.FormC)
            .Replace('đ', 'd')
            .Replace('Đ', 'D');
    }

    private void GanLaiDanhSach(IEnumerable<string> danhSach)
    {
        lstHoTen.BeginUpdate();
        lstHoTen.Items.Clear();
        lstHoTen.Items.AddRange(danhSach.Cast<object>().ToArray());
        lstHoTen.EndUpdate();
        CapNhatThongKe();
    }

    private bool KiemTraCoDuLieu()
    {
        if (lstHoTen.Items.Count > 0) return true;

        MessageBox.Show(
            "Danh sách đang trống. Hãy bấm Ngẫu nhiên 50 tên trước.",
            "Thông báo",
            MessageBoxButtons.OK,
            MessageBoxIcon.Warning);
        return false;
    }

    private void CapNhatThongKe()
    {
        lblThongKe.Text =
            $"Tổng số tên: {lstHoTen.Items.Count} | " +
            $"Đang chọn: {lstHoTen.SelectedItems.Count}";
    }

    private void Form1_FormClosing(object sender, FormClosingEventArgs e)
    {
        if (MessageBox.Show(
            "Bạn có chắc muốn thoát chương trình không?",
            "Xác nhận thoát",
            MessageBoxButtons.YesNo,
            MessageBoxIcon.Question,
            MessageBoxDefaultButton.Button2) == DialogResult.No)
        {
            e.Cancel = true;
        }
    }
}
