BÀI NÂNG CAO - XỬ LÝ CHUỖI HỌ TÊN

Cách chạy:
1. Mở BaiNangCao_XuLyChuoi.csproj bằng Visual Studio.
2. Build > Rebuild Solution.
3. Nhấn F5.

Chức năng:
- Tạo 50 họ tên ngẫu nhiên từ các mảng HO, TENLOT, TEN trong đề.
- Không tạo tên trùng nhau.
- Tìm kiếm không phân biệt dấu và chữ hoa/thường.
- Sắp xếp A-Z hoặc Z-A.
- Chuẩn hóa họ tên.
- Xóa nhiều tên đang chọn hoặc xóa toàn bộ.
- Thống kê tên dài nhất, ngắn nhất, số người họ Nguyễn.
- Double-click một tên để mở hộp thoại và chỉnh sửa tại đúng vị trí.
- Kiểm tra tên sửa bị trống hoặc trùng.
- Thoát có xác nhận.
