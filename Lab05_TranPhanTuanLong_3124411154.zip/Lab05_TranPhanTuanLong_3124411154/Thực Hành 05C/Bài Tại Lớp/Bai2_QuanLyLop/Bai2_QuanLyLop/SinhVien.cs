namespace Bai2_QuanLyLop;

public class SinhVien
{
    public string MaSinhVien { get; set; } = "";
    public string HoTen { get; set; } = "";
    public string DiaChi { get; set; } = "";
}
