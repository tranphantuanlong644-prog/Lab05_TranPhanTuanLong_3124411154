namespace Bai2_QuanLyLop;

/// <summary>
/// TreeView quản lý lớp và sinh viên; dữ liệu sinh viên lưu trong Tag và chỉ node sinh viên được phép xóa.
/// </summary>
public partial class Form1 : Form
{
    public Form1()
    {
        InitializeComponent();
    }

    private void Form1_Load(object sender, EventArgs e)
    {
        string[] danhSachLop = { "DCT124C1", "DCT124C2", "DCT124C3", "DCT124C4" };

        trvDanhSach.Nodes.Clear();
        cboLop.Items.Clear();

        foreach (string tenLop in danhSachLop)
        {
            trvDanhSach.Nodes.Add(tenLop);
            cboLop.Items.Add(tenLop);
        }

        if (cboLop.Items.Count > 0)
            cboLop.SelectedIndex = 0;

        chkThemLop.Checked = false;
        grpThongTinLop.Visible = false;
        txtMaSinhVien.Focus();
    }

    private void chkThemLop_CheckedChanged(object sender, EventArgs e)
    {
        grpThongTinLop.Visible = chkThemLop.Checked;
        if (chkThemLop.Checked)
        {
            txtTenLop.Clear();
            txtTenLop.Focus();
        }
    }

    private bool LopDaTonTai(string tenLop)
    {
        foreach (TreeNode node in trvDanhSach.Nodes)
            if (string.Equals(node.Text.Trim(), tenLop.Trim(), StringComparison.OrdinalIgnoreCase))
                return true;
        return false;
    }

    private void btnThemLop_Click(object sender, EventArgs e)
    {
        string tenLop = txtTenLop.Text.Trim();

        if (string.IsNullOrWhiteSpace(tenLop))
        {
            MessageBox.Show("Vui lòng nhập tên lớp.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            txtTenLop.Focus();
            return;
        }

        if (LopDaTonTai(tenLop))
        {
            MessageBox.Show("Tên lớp đã tồn tại.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            txtTenLop.SelectAll();
            txtTenLop.Focus();
            return;
        }

        TreeNode nodeMoi = trvDanhSach.Nodes.Add(tenLop);
        cboLop.Items.Add(tenLop);
        cboLop.SelectedItem = tenLop;
        trvDanhSach.SelectedNode = nodeMoi;
        nodeMoi.EnsureVisible();

        MessageBox.Show("Thêm lớp thành công.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
        txtTenLop.Clear();
        txtTenLop.Focus();
    }

    private bool KiemTraThongTinSinhVien()
    {
        if (cboLop.SelectedIndex < 0)
        {
            MessageBox.Show("Vui lòng chọn lớp.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            cboLop.Focus();
            return false;
        }

        if (string.IsNullOrWhiteSpace(txtMaSinhVien.Text))
        {
            MessageBox.Show("Vui lòng nhập mã sinh viên.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            txtMaSinhVien.Focus();
            return false;
        }

        if (string.IsNullOrWhiteSpace(txtHoTen.Text))
        {
            MessageBox.Show("Vui lòng nhập họ tên.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            txtHoTen.Focus();
            return false;
        }

        if (string.IsNullOrWhiteSpace(txtDiaChi.Text))
        {
            MessageBox.Show("Vui lòng nhập địa chỉ.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            txtDiaChi.Focus();
            return false;
        }

        return true;
    }

    private TreeNode TimNodeLop(string tenLop)
    {
        foreach (TreeNode node in trvDanhSach.Nodes)
            if (string.Equals(node.Text, tenLop, StringComparison.OrdinalIgnoreCase))
                return node;
        return null;
    }

    private bool MaSinhVienDaTonTai(string maSinhVien)
    {
        foreach (TreeNode nodeLop in trvDanhSach.Nodes)
        foreach (TreeNode nodeSinhVien in nodeLop.Nodes)
        {
            SinhVien sv = nodeSinhVien.Tag as SinhVien;
            if (sv != null && string.Equals(sv.MaSinhVien, maSinhVien, StringComparison.OrdinalIgnoreCase))
                return true;
        }
        return false;
    }

    private void btnCapNhat_Click(object sender, EventArgs e)
    {
        if (!KiemTraThongTinSinhVien()) return;

        string ma = txtMaSinhVien.Text.Trim();
        if (MaSinhVienDaTonTai(ma))
        {
            MessageBox.Show("Mã sinh viên đã tồn tại.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            txtMaSinhVien.SelectAll();
            txtMaSinhVien.Focus();
            return;
        }

        TreeNode nodeLop = TimNodeLop(cboLop.Text);
        if (nodeLop == null)
        {
            MessageBox.Show("Không tìm thấy lớp đã chọn.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return;
        }

        SinhVien sv = new SinhVien
        {
            MaSinhVien = ma,
            HoTen = txtHoTen.Text.Trim(),
            DiaChi = txtDiaChi.Text.Trim()
        };

        TreeNode nodeSV = new TreeNode($"{sv.MaSinhVien} - {sv.HoTen}") { Tag = sv };
        nodeLop.Nodes.Add(nodeSV);
        nodeLop.Expand();
        trvDanhSach.SelectedNode = nodeSV;
        nodeSV.EnsureVisible();

        MessageBox.Show("Thêm sinh viên thành công.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
        XoaThongTinSinhVien();
        txtMaSinhVien.Focus();
    }

    private void XoaThongTinSinhVien()
    {
        txtMaSinhVien.Clear();
        txtHoTen.Clear();
        txtDiaChi.Clear();
    }

    private void btnXoa_Click(object sender, EventArgs e)
    {
        TreeNode node = trvDanhSach.SelectedNode;
        if (node == null)
        {
            MessageBox.Show("Vui lòng chọn sinh viên cần xóa.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        if (node.Parent == null)
        {
            MessageBox.Show("Chỉ được phép xóa node sinh viên.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        DialogResult kq = MessageBox.Show($"Bạn có chắc muốn xóa sinh viên:\n{node.Text}?", "Xác nhận xóa",
            MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);

        if (kq == DialogResult.Yes)
        {
            node.Remove();
            XoaThongTinSinhVien();
            MessageBox.Show("Xóa sinh viên thành công.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }

    private void trvDanhSach_AfterSelect(object sender, TreeViewEventArgs e)
    {
        TreeNode node = e.Node;
        if (node == null) return;

        if (node.Parent == null)
        {
            cboLop.SelectedItem = node.Text;
            XoaThongTinSinhVien();
            return;
        }

        SinhVien sv = node.Tag as SinhVien;
        if (sv != null)
        {
            cboLop.SelectedItem = node.Parent.Text;
            txtMaSinhVien.Text = sv.MaSinhVien;
            txtHoTen.Text = sv.HoTen;
            txtDiaChi.Text = sv.DiaChi;
        }
    }

    private void btnThoat_Click(object sender, EventArgs e) => Close();

    private void Form1_FormClosing(object sender, FormClosingEventArgs e)
    {
        DialogResult kq = MessageBox.Show("Bạn có chắc muốn thoát chương trình không?", "Xác nhận thoát",
            MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);
        if (kq == DialogResult.No) e.Cancel = true;
    }
}
