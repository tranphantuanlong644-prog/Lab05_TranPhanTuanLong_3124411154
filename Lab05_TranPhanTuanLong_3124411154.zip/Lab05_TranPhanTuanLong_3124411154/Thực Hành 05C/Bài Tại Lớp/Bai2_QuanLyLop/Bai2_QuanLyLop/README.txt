BÀI 2 - QUẢN LÝ LỚP VÀ SINH VIÊN

Cách chạy:
1. Mở Bai2_QuanLyLop.csproj bằng Visual Studio.
2. Chọn Build > Rebuild Solution.
3. Nhấn F5.

Chức năng:
- Có sẵn 4 lớp DCT124C1 đến DCT124C4.
- Checkbox Thêm lớp hiện/ẩn vùng nhập lớp.
- Kiểm tra trùng tên lớp.
- Thêm sinh viên theo lớp, kiểm tra trống và trùng MSSV.
- Chọn node sinh viên để xem thông tin.
- Chỉ cho xóa node sinh viên và có xác nhận.
- Thoát chương trình có xác nhận.
