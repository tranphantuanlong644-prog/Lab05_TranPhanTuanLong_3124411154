namespace Bai2_QuanLyLop;

partial class Form1
{
    private System.ComponentModel.IContainer components = null;

    protected override void Dispose(bool disposing)
    {
        if (disposing && components != null) components.Dispose();
        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        lblTieuDe = new Label();
        lblDanhSach = new Label();
        trvDanhSach = new TreeView();
        chkThemLop = new CheckBox();
        grpThongTinLop = new GroupBox();
        lblTenLop = new Label();
        txtTenLop = new TextBox();
        btnThemLop = new Button();
        grpThongTinSinhVien = new GroupBox();
        lblChonLop = new Label();
        cboLop = new ComboBox();
        lblMaSinhVien = new Label();
        txtMaSinhVien = new TextBox();
        lblHoTen = new Label();
        txtHoTen = new TextBox();
        lblDiaChi = new Label();
        txtDiaChi = new TextBox();
        btnCapNhat = new Button();
        btnXoa = new Button();
        btnThoat = new Button();
        grpThongTinLop.SuspendLayout();
        grpThongTinSinhVien.SuspendLayout();
        SuspendLayout();

        lblTieuDe.AutoSize = true;
        lblTieuDe.Font = new Font("Tahoma", 18F, FontStyle.Bold);
        lblTieuDe.ForeColor = Color.DarkBlue;
        lblTieuDe.Location = new Point(230, 22);
        lblTieuDe.Text = "QUẢN LÝ LỚP VÀ SINH VIÊN";

        lblDanhSach.AutoSize = true;
        lblDanhSach.Font = new Font("Tahoma", 11F, FontStyle.Bold);
        lblDanhSach.Location = new Point(35, 85);
        lblDanhSach.Text = "Danh sách lớp:";

        trvDanhSach.FullRowSelect = true;
        trvDanhSach.HideSelection = false;
        trvDanhSach.Location = new Point(35, 118);
        trvDanhSach.Name = "trvDanhSach";
        trvDanhSach.Size = new Size(315, 385);
        trvDanhSach.AfterSelect += trvDanhSach_AfterSelect;

        chkThemLop.AutoSize = true;
        chkThemLop.Location = new Point(35, 522);
        chkThemLop.Name = "chkThemLop";
        chkThemLop.Text = "&Thêm lớp";
        chkThemLop.CheckedChanged += chkThemLop_CheckedChanged;

        grpThongTinLop.Controls.Add(lblTenLop);
        grpThongTinLop.Controls.Add(txtTenLop);
        grpThongTinLop.Controls.Add(btnThemLop);
        grpThongTinLop.Location = new Point(35, 563);
        grpThongTinLop.Name = "grpThongTinLop";
        grpThongTinLop.Size = new Size(750, 105);
        grpThongTinLop.Text = "Thông tin lớp";
        grpThongTinLop.Visible = false;

        lblTenLop.AutoSize = true;
        lblTenLop.Location = new Point(30, 47);
        lblTenLop.Text = "Tên lớp:";

        txtTenLop.Location = new Point(130, 43);
        txtTenLop.Name = "txtTenLop";
        txtTenLop.Size = new Size(370, 30);

        btnThemLop.Location = new Point(540, 39);
        btnThemLop.Name = "btnThemLop";
        btnThemLop.Size = new Size(165, 39);
        btnThemLop.Text = "Thêm &lớp";
        btnThemLop.Click += btnThemLop_Click;

        grpThongTinSinhVien.Controls.Add(lblChonLop);
        grpThongTinSinhVien.Controls.Add(cboLop);
        grpThongTinSinhVien.Controls.Add(lblMaSinhVien);
        grpThongTinSinhVien.Controls.Add(txtMaSinhVien);
        grpThongTinSinhVien.Controls.Add(lblHoTen);
        grpThongTinSinhVien.Controls.Add(txtHoTen);
        grpThongTinSinhVien.Controls.Add(lblDiaChi);
        grpThongTinSinhVien.Controls.Add(txtDiaChi);
        grpThongTinSinhVien.Controls.Add(btnCapNhat);
        grpThongTinSinhVien.Controls.Add(btnXoa);
        grpThongTinSinhVien.Location = new Point(385, 85);
        grpThongTinSinhVien.Name = "grpThongTinSinhVien";
        grpThongTinSinhVien.Size = new Size(400, 418);
        grpThongTinSinhVien.Text = "Thông tin sinh viên";

        lblChonLop.AutoSize = true;
        lblChonLop.Location = new Point(30, 52);
        lblChonLop.Text = "Chọn lớp:";
        cboLop.DropDownStyle = ComboBoxStyle.DropDownList;
        cboLop.Location = new Point(155, 48);
        cboLop.Name = "cboLop";
        cboLop.Size = new Size(205, 30);

        lblMaSinhVien.AutoSize = true;
        lblMaSinhVien.Location = new Point(30, 113);
        lblMaSinhVien.Text = "Mã sinh viên:";
        txtMaSinhVien.Location = new Point(155, 109);
        txtMaSinhVien.Name = "txtMaSinhVien";
        txtMaSinhVien.Size = new Size(205, 30);

        lblHoTen.AutoSize = true;
        lblHoTen.Location = new Point(30, 174);
        lblHoTen.Text = "Họ tên:";
        txtHoTen.Location = new Point(155, 170);
        txtHoTen.Name = "txtHoTen";
        txtHoTen.Size = new Size(205, 30);

        lblDiaChi.AutoSize = true;
        lblDiaChi.Location = new Point(30, 235);
        lblDiaChi.Text = "Địa chỉ:";
        txtDiaChi.Location = new Point(155, 230);
        txtDiaChi.Multiline = true;
        txtDiaChi.Name = "txtDiaChi";
        txtDiaChi.ScrollBars = ScrollBars.Vertical;
        txtDiaChi.Size = new Size(205, 75);

        btnCapNhat.Location = new Point(65, 342);
        btnCapNhat.Name = "btnCapNhat";
        btnCapNhat.Size = new Size(130, 42);
        btnCapNhat.Text = "&Cập nhật";
        btnCapNhat.Click += btnCapNhat_Click;

        btnXoa.Location = new Point(230, 342);
        btnXoa.Name = "btnXoa";
        btnXoa.Size = new Size(130, 42);
        btnXoa.Text = "&Xóa";
        btnXoa.Click += btnXoa_Click;

        btnThoat.DialogResult = DialogResult.Cancel;
        btnThoat.Location = new Point(655, 696);
        btnThoat.Name = "btnThoat";
        btnThoat.Size = new Size(130, 42);
        btnThoat.Text = "Th&oát";
        btnThoat.Click += btnThoat_Click;

        AutoScaleDimensions = new SizeF(10F, 22F);
        AutoScaleMode = AutoScaleMode.Font;
        CancelButton = btnThoat;
        ClientSize = new Size(825, 760);
        Controls.Add(lblTieuDe);
        Controls.Add(lblDanhSach);
        Controls.Add(trvDanhSach);
        Controls.Add(chkThemLop);
        Controls.Add(grpThongTinLop);
        Controls.Add(grpThongTinSinhVien);
        Controls.Add(btnThoat);
        Font = new Font("Tahoma", 11F);
        FormBorderStyle = FormBorderStyle.FixedSingle;
        MaximizeBox = false;
        Name = "Form1";
        StartPosition = FormStartPosition.CenterScreen;
        Text = "Quản lý lớp và sinh viên";
        Load += Form1_Load;
        FormClosing += Form1_FormClosing;

        grpThongTinLop.ResumeLayout(false);
        grpThongTinLop.PerformLayout();
        grpThongTinSinhVien.ResumeLayout(false);
        grpThongTinSinhVien.PerformLayout();
        ResumeLayout(false);
        PerformLayout();
    }

    private Label lblTieuDe;
    private Label lblDanhSach;
    private TreeView trvDanhSach;
    private CheckBox chkThemLop;
    private GroupBox grpThongTinLop;
    private Label lblTenLop;
    private TextBox txtTenLop;
    private Button btnThemLop;
    private GroupBox grpThongTinSinhVien;
    private Label lblChonLop;
    private ComboBox cboLop;
    private Label lblMaSinhVien;
    private TextBox txtMaSinhVien;
    private Label lblHoTen;
    private TextBox txtHoTen;
    private Label lblDiaChi;
    private TextBox txtDiaChi;
    private Button btnCapNhat;
    private Button btnXoa;
    private Button btnThoat;
}
