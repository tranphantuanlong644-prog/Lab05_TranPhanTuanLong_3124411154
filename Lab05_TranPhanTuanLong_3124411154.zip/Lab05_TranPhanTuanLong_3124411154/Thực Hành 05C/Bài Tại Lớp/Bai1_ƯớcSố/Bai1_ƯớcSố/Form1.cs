using System;
using System.Windows.Forms;

namespace Bai1_UocSo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // =====================================================
        // KIỂM TRA DỮ LIỆU NHẬP
        // =====================================================
        private bool KiemTraDuLieu(out int so)
        {
            so = 0;

            // Kiểm tra TextBox có bị bỏ trống hay không
            if (string.IsNullOrWhiteSpace(txtNhapSo.Text))
            {
                MessageBox.Show(
                    "Vui lòng nhập số.",
                    "Thông báo",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                txtNhapSo.Focus();
                return false;
            }

            // Kiểm tra dữ liệu có phải số nguyên hay không
            if (!int.TryParse(txtNhapSo.Text.Trim(), out so))
            {
                MessageBox.Show(
                    "Dữ liệu nhập phải là số nguyên.",
                    "Dữ liệu không hợp lệ",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);

                txtNhapSo.SelectAll();
                txtNhapSo.Focus();
                return false;
            }

            // Chỉ chấp nhận số nguyên dương
            if (so <= 0)
            {
                MessageBox.Show(
                    "Vui lòng nhập số nguyên dương lớn hơn 0.",
                    "Dữ liệu không hợp lệ",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                txtNhapSo.SelectAll();
                txtNhapSo.Focus();
                return false;
            }

            return true;
        }

        // =====================================================
        // KIỂM TRA SỐ ĐÃ TỒN TẠI TRONG COMBOBOX CHƯA
        // =====================================================
        private bool SoDaTonTai(int so)
        {
            foreach (object item in cboSo.Items)
            {
                if (Convert.ToInt32(item) == so)
                {
                    return true;
                }
            }

            return false;
        }

        // =====================================================
        // BUTTON CẬP NHẬT
        // =====================================================
        private void btnCapNhat_Click(object sender, EventArgs e)
        {
            // Kiểm tra dữ liệu nhập
            if (!KiemTraDuLieu(out int so))
            {
                return;
            }

            // Kiểm tra số đã có trong ComboBox chưa
            if (SoDaTonTai(so))
            {
                MessageBox.Show(
                    "Số này đã tồn tại trong danh sách.",
                    "Thông báo",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                txtNhapSo.SelectAll();
                txtNhapSo.Focus();
                return;
            }

            // Thêm số vào ComboBox
            cboSo.Items.Add(so);

            // Chọn số vừa thêm
            cboSo.SelectedItem = so;

            // Xóa TextBox và đặt con trỏ trở lại
            txtNhapSo.Clear();
            txtNhapSo.Focus();
        }

        // =====================================================
        // KHI CHỌN SỐ TRONG COMBOBOX
        // HIỂN THỊ DANH SÁCH ƯỚC SỐ
        // =====================================================
        private void cboSo_SelectedIndexChanged(
            object sender,
            EventArgs e)
        {
            // Xóa danh sách ước cũ
            lstUocSo.Items.Clear();

            if (cboSo.SelectedIndex < 0)
            {
                return;
            }

            int soDuocChon = Convert.ToInt32(cboSo.SelectedItem);

            // Tìm các ước số
            for (int i = 1; i <= soDuocChon; i++)
            {
                if (soDuocChon % i == 0)
                {
                    lstUocSo.Items.Add(i);
                }
            }
        }

        // =====================================================
        // KIỂM TRA DANH SÁCH ƯỚC SỐ
        // =====================================================
        private bool KiemTraDanhSachUoc()
        {
            if (cboSo.SelectedIndex < 0 ||
                lstUocSo.Items.Count == 0)
            {
                MessageBox.Show(
                    "Vui lòng chọn một số trong ComboBox.",
                    "Thông báo",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                cboSo.Focus();
                return false;
            }

            return true;
        }

        // =====================================================
        // TÍNH TỔNG CÁC ƯỚC SỐ
        // =====================================================
        private void btnTongUoc_Click(object sender, EventArgs e)
        {
            if (!KiemTraDanhSachUoc())
            {
                return;
            }

            int tong = 0;

            foreach (object item in lstUocSo.Items)
            {
                tong += Convert.ToInt32(item);
            }

            MessageBox.Show(
                $"Tổng các ước số là: {tong}",
                "Kết quả",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
        }

        // =====================================================
        // ĐẾM SỐ LƯỢNG ƯỚC SỐ CHẴN
        // =====================================================
        private void btnDemUocChan_Click(
            object sender,
            EventArgs e)
        {
            if (!KiemTraDanhSachUoc())
            {
                return;
            }

            int soLuongUocChan = 0;

            foreach (object item in lstUocSo.Items)
            {
                int uocSo = Convert.ToInt32(item);

                if (uocSo % 2 == 0)
                {
                    soLuongUocChan++;
                }
            }

            MessageBox.Show(
                $"Số lượng các ước số chẵn là: {soLuongUocChan}",
                "Kết quả",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
        }

        // =====================================================
        // KIỂM TRA SỐ NGUYÊN TỐ
        // =====================================================
        private bool LaSoNguyenTo(int so)
        {
            if (so < 2)
            {
                return false;
            }

            for (int i = 2; i * i <= so; i++)
            {
                if (so % i == 0)
                {
                    return false;
                }
            }

            return true;
        }

        // =====================================================
        // ĐẾM SỐ LƯỢNG ƯỚC SỐ NGUYÊN TỐ
        // =====================================================
        private void btnDemUocNguyenTo_Click(
            object sender,
            EventArgs e)
        {
            if (!KiemTraDanhSachUoc())
            {
                return;
            }

            int soLuongUocNguyenTo = 0;

            foreach (object item in lstUocSo.Items)
            {
                int uocSo = Convert.ToInt32(item);

                if (LaSoNguyenTo(uocSo))
                {
                    soLuongUocNguyenTo++;
                }
            }

            MessageBox.Show(
                $"Số lượng các ước số nguyên tố là: " +
                $"{soLuongUocNguyenTo}",
                "Kết quả",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
        }

        // =====================================================
        // BUTTON THOÁT
        // =====================================================
        private void btnThoat_Click(object sender, EventArgs e)
        {
            Close();
        }

        // =====================================================
        // XÁC NHẬN KHI ĐÓNG FORM
        // =====================================================
        private void Form1_FormClosing(
            object sender,
            FormClosingEventArgs e)
        {
            DialogResult ketQua = MessageBox.Show(
                "Bạn có chắc muốn thoát chương trình không?",
                "Xác nhận thoát",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question,
                MessageBoxDefaultButton.Button2);

            if (ketQua == DialogResult.No)
            {
                e.Cancel = true;
            }
        }

        // =====================================================
        // CHỈ CHO NHẬP CHỮ SỐ
        // =====================================================
        private void txtNhapSo_KeyPress(
            object sender,
            KeyPressEventArgs e)
        {
            // Cho phép Backspace và các phím điều khiển
            if (char.IsControl(e.KeyChar))
            {
                return;
            }

            // Không cho nhập ký tự không phải số
            if (!char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }
    }
}