﻿namespace Bai1_UocSo
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null)
            {
                components.Dispose();
            }

            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            lblTieuDe = new Label();
            lblNhapSo = new Label();
            txtNhapSo = new TextBox();
            btnCapNhat = new Button();
            lblChonSo = new Label();
            cboSo = new ComboBox();
            lblDanhSachUoc = new Label();
            lstUocSo = new ListBox();
            btnTongUoc = new Button();
            btnDemUocChan = new Button();
            btnDemUocNguyenTo = new Button();
            btnThoat = new Button();

            SuspendLayout();

            // 
            // lblTieuDe
            // 
            lblTieuDe.AutoSize = true;
            lblTieuDe.Font = new Font(
                "Tahoma",
                18F,
                FontStyle.Bold,
                GraphicsUnit.Point);

            lblTieuDe.ForeColor = Color.DarkBlue;
            lblTieuDe.Location = new Point(205, 25);
            lblTieuDe.Name = "lblTieuDe";
            lblTieuDe.Size = new Size(196, 36);
            lblTieuDe.TabIndex = 0;
            lblTieuDe.Text = "TÌM ƯỚC SỐ";

            // 
            // lblNhapSo
            // 
            lblNhapSo.AutoSize = true;
            lblNhapSo.Location = new Point(50, 94);
            lblNhapSo.Name = "lblNhapSo";
            lblNhapSo.Size = new Size(79, 22);
            lblNhapSo.TabIndex = 1;
            lblNhapSo.Text = "Nhập số:";

            // 
            // txtNhapSo
            // 
            txtNhapSo.Location = new Point(150, 90);
            txtNhapSo.Name = "txtNhapSo";
            txtNhapSo.Size = new Size(210, 30);
            txtNhapSo.TabIndex = 2;
            txtNhapSo.KeyPress += txtNhapSo_KeyPress;

            // 
            // btnCapNhat
            // 
            btnCapNhat.Location = new Point(390, 87);
            btnCapNhat.Name = "btnCapNhat";
            btnCapNhat.Size = new Size(140, 37);
            btnCapNhat.TabIndex = 3;
            btnCapNhat.Text = "&Cập nhật";
            btnCapNhat.UseVisualStyleBackColor = true;
            btnCapNhat.Click += btnCapNhat_Click;

            // 
            // lblChonSo
            // 
            lblChonSo.AutoSize = true;
            lblChonSo.Location = new Point(50, 151);
            lblChonSo.Name = "lblChonSo";
            lblChonSo.Size = new Size(77, 22);
            lblChonSo.TabIndex = 4;
            lblChonSo.Text = "Chọn số:";

            // 
            // cboSo
            // 
            cboSo.DropDownStyle = ComboBoxStyle.DropDownList;
            cboSo.FormattingEnabled = true;
            cboSo.Location = new Point(150, 147);
            cboSo.Name = "cboSo";
            cboSo.Size = new Size(210, 30);
            cboSo.TabIndex = 5;
            cboSo.SelectedIndexChanged += cboSo_SelectedIndexChanged;

            // 
            // lblDanhSachUoc
            // 
            lblDanhSachUoc.AutoSize = true;
            lblDanhSachUoc.Location = new Point(50, 207);
            lblDanhSachUoc.Name = "lblDanhSachUoc";
            lblDanhSachUoc.Size = new Size(183, 22);
            lblDanhSachUoc.TabIndex = 6;
            lblDanhSachUoc.Text = "Danh sách các ước số:";

            // 
            // lstUocSo
            // 
            lstUocSo.FormattingEnabled = true;
            lstUocSo.ItemHeight = 22;
            lstUocSo.Location = new Point(50, 240);
            lstUocSo.Name = "lstUocSo";
            lstUocSo.Size = new Size(310, 180);
            lstUocSo.TabIndex = 7;

            // 
            // btnTongUoc
            // 
            btnTongUoc.Location = new Point(390, 240);
            btnTongUoc.Name = "btnTongUoc";
            btnTongUoc.Size = new Size(205, 45);
            btnTongUoc.TabIndex = 8;
            btnTongUoc.Text = "&Tổng các ước số";
            btnTongUoc.UseVisualStyleBackColor = true;
            btnTongUoc.Click += btnTongUoc_Click;

            // 
            // btnDemUocChan
            // 
            btnDemUocChan.Location = new Point(390, 305);
            btnDemUocChan.Name = "btnDemUocChan";
            btnDemUocChan.Size = new Size(205, 48);
            btnDemUocChan.TabIndex = 9;
            btnDemUocChan.Text = "Số lượng ước c&hẵn";
            btnDemUocChan.UseVisualStyleBackColor = true;
            btnDemUocChan.Click += btnDemUocChan_Click;

            // 
            // btnDemUocNguyenTo
            // 
            btnDemUocNguyenTo.Location = new Point(390, 373);
            btnDemUocNguyenTo.Name = "btnDemUocNguyenTo";
            btnDemUocNguyenTo.Size = new Size(205, 48);
            btnDemUocNguyenTo.TabIndex = 10;
            btnDemUocNguyenTo.Text = "Ước số &nguyên tố";
            btnDemUocNguyenTo.UseVisualStyleBackColor = true;
            btnDemUocNguyenTo.Click += btnDemUocNguyenTo_Click;

            // 
            // btnThoat
            // 
            btnThoat.DialogResult = DialogResult.Cancel;
            btnThoat.Location = new Point(475, 450);
            btnThoat.Name = "btnThoat";
            btnThoat.Size = new Size(120, 40);
            btnThoat.TabIndex = 11;
            btnThoat.Text = "Th&oát";
            btnThoat.UseVisualStyleBackColor = true;
            btnThoat.Click += btnThoat_Click;

            // 
            // Form1
            // 
            AcceptButton = btnCapNhat;
            AutoScaleDimensions = new SizeF(10F, 22F);
            AutoScaleMode = AutoScaleMode.Font;
            CancelButton = btnThoat;
            ClientSize = new Size(650, 520);

            Controls.Add(btnThoat);
            Controls.Add(btnDemUocNguyenTo);
            Controls.Add(btnDemUocChan);
            Controls.Add(btnTongUoc);
            Controls.Add(lstUocSo);
            Controls.Add(lblDanhSachUoc);
            Controls.Add(cboSo);
            Controls.Add(lblChonSo);
            Controls.Add(btnCapNhat);
            Controls.Add(txtNhapSo);
            Controls.Add(lblNhapSo);
            Controls.Add(lblTieuDe);

            Font = new Font(
                "Tahoma",
                11F,
                FontStyle.Regular,
                GraphicsUnit.Point);

            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Tìm ước số";

            FormClosing += Form1_FormClosing;

            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblTieuDe;
        private Label lblNhapSo;
        private TextBox txtNhapSo;
        private Button btnCapNhat;
        private Label lblChonSo;
        private ComboBox cboSo;
        private Label lblDanhSachUoc;
        private ListBox lstUocSo;
        private Button btnTongUoc;
        private Button btnDemUocChan;
        private Button btnDemUocNguyenTo;
        private Button btnThoat;
    }
}