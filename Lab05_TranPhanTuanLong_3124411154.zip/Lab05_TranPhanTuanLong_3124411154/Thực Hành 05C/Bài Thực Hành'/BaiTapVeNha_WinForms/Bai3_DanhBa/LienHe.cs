namespace Bai3_DanhBa;
public class LienHe
{
 public string HoTen {get;set;}=""; public string DienThoai {get;set;}=""; public string DiaChi {get;set;}="";
}
