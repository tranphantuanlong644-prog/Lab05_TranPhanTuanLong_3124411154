using System.Globalization;
using System.Text;
namespace Bai3_DanhBa;

/// <summary>
/// Danh bạ được nhóm theo chữ cái A-Z; đối tượng liên hệ lưu trong TreeNode.Tag để đọc lại khi chọn.
/// </summary>
public class Form1 : Form
{
    readonly TreeView trv=new(); readonly TextBox txtTen=new(),txtDT=new(),txtDC=new(); readonly Button btnThem=new(),btnXoa=new(),btnThoat=new();
    public Form1()
    {
        Text="Danh bạ A - Z";StartPosition=FormStartPosition.CenterScreen;ClientSize=new Size(820,575);Font=new Font("Tahoma",11);FormBorderStyle=FormBorderStyle.FixedSingle;MaximizeBox=false;
        var title=new Label{Text="DANH BẠ ĐIỆN THOẠI",Font=new Font("Tahoma",18,FontStyle.Bold),ForeColor=Color.DarkBlue,AutoSize=true,Location=new Point(245,22)};
        trv.Location=new Point(40,85);trv.Size=new Size(330,430);trv.HideSelection=false;
        var group=new GroupBox{Text="Thông tin liên hệ",Location=new Point(405,85),Size=new Size(370,350)};
        var l1=new Label{Text="Họ tên:",AutoSize=true,Location=new Point(28,55)};txtTen.Location=new Point(130,50);txtTen.Size=new Size(205,30);
        var l2=new Label{Text="Điện thoại:",AutoSize=true,Location=new Point(28,115)};txtDT.Location=new Point(130,110);txtDT.Size=new Size(205,30);
        var l3=new Label{Text="Địa chỉ:",AutoSize=true,Location=new Point(28,175)};txtDC.Location=new Point(130,170);txtDC.Size=new Size(205,75);txtDC.Multiline=true;
        btnThem.Text="&Thêm";btnThem.Location=new Point(55,275);btnThem.Size=new Size(120,40);btnXoa.Text="&Xóa";btnXoa.Location=new Point(210,275);btnXoa.Size=new Size(120,40);
        group.Controls.AddRange(new Control[]{l1,txtTen,l2,txtDT,l3,txtDC,btnThem,btnXoa});btnThoat.Text="Th&oát";btnThoat.Location=new Point(655,475);btnThoat.Size=new Size(120,40);
        Controls.AddRange(new Control[]{title,trv,group,btnThoat});Load+=(_,__)=>TaoNodeAZ();btnThem.Click+=(_,__)=>ThemLienHe();btnXoa.Click+=(_,__)=>XoaLienHe();trv.AfterSelect+=ChonNode;btnThoat.Click+=(_,__)=>Close();FormClosing+=XacNhanThoat;
    }
    void TaoNodeAZ(){trv.Nodes.Clear();for(char c='A';c<='Z';c++)trv.Nodes.Add(c.ToString());}
    string BoDau(string s){string d=s.Normalize(NormalizationForm.FormD);return string.Concat(d.Where(c=>CharUnicodeInfo.GetUnicodeCategory(c)!=UnicodeCategory.NonSpacingMark)).Normalize(NormalizationForm.FormC);}
    TreeNode NodeTheoTen(string hoTen){string[] p=hoTen.Trim().Split(' ',StringSplitOptions.RemoveEmptyEntries);if(p.Length==0)return null;char c=char.ToUpper(BoDau(p[^1])[0]);return trv.Nodes.Cast<TreeNode>().FirstOrDefault(n=>n.Text==c.ToString());}
    bool Trung(string ten,string dt)=>trv.Nodes.Cast<TreeNode>().SelectMany(n=>n.Nodes.Cast<TreeNode>()).Any(n=>n.Tag is LienHe x&&(x.HoTen.Equals(ten,StringComparison.OrdinalIgnoreCase)||x.DienThoai==dt));
    void ThemLienHe(){string ten=txtTen.Text.Trim(),dt=txtDT.Text.Trim(),dc=txtDC.Text.Trim();if(ten==""||dt==""||dc==""){MessageBox.Show("Vui lòng nhập đầy đủ thông tin.");return;}if(Trung(ten,dt)){MessageBox.Show("Tên hoặc số điện thoại đã tồn tại.");return;}TreeNode g=NodeTheoTen(ten);if(g==null){MessageBox.Show("Không xác định được chữ cái đầu của tên.");return;}var lh=new LienHe{HoTen=ten,DienThoai=dt,DiaChi=dc};var n=new TreeNode($"{ten} - {dt}"){Tag=lh};g.Nodes.Add(n);g.Expand();trv.SelectedNode=n;MessageBox.Show("Thêm liên hệ thành công.");XoaTrang();}
    void XoaLienHe(){TreeNode n=trv.SelectedNode;if(n==null||n.Parent==null){MessageBox.Show("Chỉ được xóa node liên hệ.");return;}if(MessageBox.Show($"Xóa {n.Text}?","Xác nhận",MessageBoxButtons.YesNo,MessageBoxIcon.Question)==DialogResult.Yes){n.Remove();XoaTrang();}}
    void ChonNode(object s,TreeViewEventArgs e){if(e.Node.Tag is LienHe x){txtTen.Text=x.HoTen;txtDT.Text=x.DienThoai;txtDC.Text=x.DiaChi;}else XoaTrang();}
    void XoaTrang(){txtTen.Clear();txtDT.Clear();txtDC.Clear();txtTen.Focus();}
    void XacNhanThoat(object s,FormClosingEventArgs e){if(MessageBox.Show("Bạn có chắc muốn thoát?","Xác nhận",MessageBoxButtons.YesNo,MessageBoxIcon.Question)==DialogResult.No)e.Cancel=true;}
}
