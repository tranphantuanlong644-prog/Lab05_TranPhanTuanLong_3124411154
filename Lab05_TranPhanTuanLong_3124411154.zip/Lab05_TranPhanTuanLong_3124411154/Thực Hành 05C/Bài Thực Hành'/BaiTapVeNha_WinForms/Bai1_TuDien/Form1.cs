namespace Bai1_TuDien;

/// <summary>
/// Hai từ điển dùng chung giao diện tra cứu; danh sách gợi ý được lọc theo hướng dịch đang chọn.
/// </summary>
public class Form1 : Form
{
    readonly ComboBox cboTu = new();
    readonly TextBox txtNghia = new();
    readonly RadioButton radAnhViet = new();
    readonly RadioButton radVietAnh = new();
    readonly Button btnTra = new();
    readonly Button btnThoat = new();
    readonly ListBox lstGoiY = new();

    readonly Dictionary<string,string> anhViet = new(StringComparer.OrdinalIgnoreCase)
    {
        ["apple"]="quả táo", ["book"]="quyển sách", ["computer"]="máy tính",
        ["school"]="trường học", ["student"]="sinh viên", ["teacher"]="giáo viên",
        ["water"]="nước", ["friend"]="bạn bè", ["family"]="gia đình", ["hello"]="xin chào"
    };
    Dictionary<string,string> vietAnh;

    public Form1()
    {
        vietAnh = anhViet.ToDictionary(x => x.Value, x => x.Key, StringComparer.OrdinalIgnoreCase);
        Text="Từ điển Anh - Việt và Việt - Anh"; StartPosition=FormStartPosition.CenterScreen;
        ClientSize=new Size(760,480); Font=new Font("Tahoma",11); FormBorderStyle=FormBorderStyle.FixedSingle; MaximizeBox=false;
        var title=new Label{Text="TỪ ĐIỂN ANH - VIỆT / VIỆT - ANH",Font=new Font("Tahoma",18,FontStyle.Bold),ForeColor=Color.DarkBlue,AutoSize=true,Location=new Point(120,25)};
        radAnhViet.Text="Anh - Việt"; radAnhViet.Location=new Point(95,90); radAnhViet.AutoSize=true; radAnhViet.Checked=true;
        radVietAnh.Text="Việt - Anh"; radVietAnh.Location=new Point(230,90); radVietAnh.AutoSize=true;
        var l1=new Label{Text="Từ cần tra:",AutoSize=true,Location=new Point(45,145)};
        cboTu.Location=new Point(155,140); cboTu.Size=new Size(250,30); cboTu.DropDownStyle=ComboBoxStyle.DropDown;
        btnTra.Text="&Tra từ"; btnTra.Location=new Point(430,137); btnTra.Size=new Size(120,38);
        lstGoiY.Location=new Point(45,195); lstGoiY.Size=new Size(360,220);
        txtNghia.Location=new Point(430,195); txtNghia.Size=new Size(280,160); txtNghia.Multiline=true; txtNghia.ReadOnly=true; txtNghia.Font=new Font("Tahoma",13);
        btnThoat.Text="Th&oát"; btnThoat.Location=new Point(590,377); btnThoat.Size=new Size(120,38);
        Controls.AddRange(new Control[]{title,radAnhViet,radVietAnh,l1,cboTu,btnTra,lstGoiY,txtNghia,btnThoat});
        Load += (_,__)=>NapDanhSach(); radAnhViet.CheckedChanged += (_,__)=>NapDanhSach(); radVietAnh.CheckedChanged += (_,__)=>NapDanhSach();
        cboTu.TextUpdate += (_,__)=>LocGoiY(); btnTra.Click += (_,__)=>TraTu(); cboTu.KeyDown += CboTu_KeyDown;
        lstGoiY.DoubleClick += (_,__)=>{if(lstGoiY.SelectedItem!=null){cboTu.Text=lstGoiY.SelectedItem.ToString();TraTu();}};
        btnThoat.Click += (_,__)=>Close(); FormClosing += XacNhanThoat;
    }
    Dictionary<string,string> TuDienHienTai()=>radAnhViet.Checked?anhViet:vietAnh;
    void NapDanhSach(){cboTu.Text="";txtNghia.Clear();var keys=TuDienHienTai().Keys.OrderBy(x=>x).ToArray();cboTu.Items.Clear();cboTu.Items.AddRange(keys);lstGoiY.Items.Clear();lstGoiY.Items.AddRange(keys);}
    void LocGoiY(){string s=cboTu.Text.Trim();var k=TuDienHienTai().Keys.Where(x=>x.StartsWith(s,StringComparison.OrdinalIgnoreCase)).OrderBy(x=>x).ToArray();lstGoiY.Items.Clear();lstGoiY.Items.AddRange(k);if(k.Length>0)lstGoiY.SelectedIndex=0;}
    void TraTu(){string tu=cboTu.Text.Trim();if(TuDienHienTai().TryGetValue(tu,out string nghia))txtNghia.Text=$"{tu}\r\n\r\nNghĩa: {nghia}";else txtNghia.Text="Không tìm thấy từ cần tra.";}
    void CboTu_KeyDown(object s,KeyEventArgs e){if(e.KeyCode==Keys.Enter){TraTu();e.SuppressKeyPress=true;}}
    void XacNhanThoat(object s,FormClosingEventArgs e){if(MessageBox.Show("Bạn có chắc muốn thoát?","Xác nhận",MessageBoxButtons.YesNo,MessageBoxIcon.Question)==DialogResult.No)e.Cancel=true;}
}
