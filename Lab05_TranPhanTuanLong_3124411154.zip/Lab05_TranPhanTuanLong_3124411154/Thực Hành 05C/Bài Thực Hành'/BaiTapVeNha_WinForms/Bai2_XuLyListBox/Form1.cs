namespace Bai2_XuLyListBox;

/// <summary>
/// Các thao tác dùng chung danh sách số; khi xóa nhiều mục, duyệt chỉ số từ cuối để không lệch vị trí.
/// </summary>
public class Form1 : Form
{
    readonly TextBox txtSo=new(); readonly ListBox lstSo=new();
    readonly Button btnThem=new(),btnTong=new(),btnXoaDauCuoi=new(),btnXoaChon=new(),btnTang2=new(),btnBinhPhuong=new(),btnChonChan=new(),btnChonLe=new(),btnThoat=new();
    public Form1()
    {
        Text="Xử lý ListBox số tự nhiên";StartPosition=FormStartPosition.CenterScreen;ClientSize=new Size(820,590);Font=new Font("Tahoma",11);FormBorderStyle=FormBorderStyle.FixedSingle;MaximizeBox=false;
        var title=new Label{Text="XỬ LÝ DANH SÁCH SỐ TỰ NHIÊN",Font=new Font("Tahoma",18,FontStyle.Bold),ForeColor=Color.DarkBlue,AutoSize=true,Location=new Point(145,22)};
        var l=new Label{Text="Nhập số N:",AutoSize=true,Location=new Point(45,92)};txtSo.Location=new Point(155,87);txtSo.Size=new Size(210,30);btnThem.Text="&Thêm";btnThem.Location=new Point(390,84);btnThem.Size=new Size(120,38);
        lstSo.Location=new Point(45,145);lstSo.Size=new Size(360,370);lstSo.SelectionMode=SelectionMode.MultiExtended;
        string[] texts={"Tính &tổng","Xóa đầu và &cuối","Xóa phần tử đang c&họn","Tăng mỗi phần tử lên &2","&Bình phương mỗi phần tử","Chọn số chẵn","Chọn số lẻ","Th&oát"};
        Button[] bs={btnTong,btnXoaDauCuoi,btnXoaChon,btnTang2,btnBinhPhuong,btnChonChan,btnChonLe,btnThoat};
        for(int i=0;i<bs.Length;i++){bs[i].Text=texts[i];bs[i].Location=new Point(455,145+i*48);bs[i].Size=new Size(300,38);Controls.Add(bs[i]);}
        Controls.AddRange(new Control[]{title,l,txtSo,btnThem,lstSo});
        btnThem.Click+=(_,__)=>ThemSo();txtSo.KeyPress+=ChiNhapSo;btnTong.Click+=(_,__)=>MessageBox.Show($"Tổng các phần tử: {lstSo.Items.Cast<object>().Sum(x=>Convert.ToInt32(x))}","Kết quả");
        btnXoaDauCuoi.Click+=(_,__)=>XoaDauCuoi();btnXoaChon.Click+=(_,__)=>XoaDangChon();btnTang2.Click+=(_,__)=>BienDoi(x=>x+2);btnBinhPhuong.Click+=(_,__)=>BienDoi(x=>x*x);btnChonChan.Click+=(_,__)=>ChonTheo(x=>x%2==0);btnChonLe.Click+=(_,__)=>ChonTheo(x=>x%2!=0);btnThoat.Click+=(_,__)=>Close();FormClosing+=XacNhanThoat;
    }
    void ThemSo(){if(!int.TryParse(txtSo.Text.Trim(),out int n)||n<0){MessageBox.Show("Vui lòng nhập số tự nhiên hợp lệ.");txtSo.Focus();return;}lstSo.Items.Add(n);txtSo.Clear();txtSo.Focus();}
    void ChiNhapSo(object s,KeyPressEventArgs e){if(!char.IsControl(e.KeyChar)&&!char.IsDigit(e.KeyChar))e.Handled=true;}
    bool CoDuLieu(){if(lstSo.Items.Count==0){MessageBox.Show("Danh sách đang trống.");return false;}return true;}
    void XoaDauCuoi(){if(!CoDuLieu())return;if(lstSo.Items.Count==1)lstSo.Items.Clear();else{lstSo.Items.RemoveAt(lstSo.Items.Count-1);lstSo.Items.RemoveAt(0);}}
    void XoaDangChon(){if(lstSo.SelectedIndices.Count==0){MessageBox.Show("Hãy chọn phần tử cần xóa.");return;}for(int i=lstSo.SelectedIndices.Count-1;i>=0;i--)lstSo.Items.RemoveAt(lstSo.SelectedIndices[i]);}
    void BienDoi(Func<int,int> f){if(!CoDuLieu())return;for(int i=0;i<lstSo.Items.Count;i++)lstSo.Items[i]=f(Convert.ToInt32(lstSo.Items[i]));}
    void ChonTheo(Func<int,bool> dk){lstSo.ClearSelected();for(int i=0;i<lstSo.Items.Count;i++)if(dk(Convert.ToInt32(lstSo.Items[i])))lstSo.SetSelected(i,true);}
    void XacNhanThoat(object s,FormClosingEventArgs e){if(MessageBox.Show("Bạn có chắc muốn thoát?","Xác nhận",MessageBoxButtons.YesNo,MessageBoxIcon.Question)==DialogResult.No)e.Cancel=true;}
}
