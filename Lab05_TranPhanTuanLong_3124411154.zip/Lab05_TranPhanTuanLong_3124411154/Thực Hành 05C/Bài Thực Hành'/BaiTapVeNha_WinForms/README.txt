BÀI TẬP VỀ NHÀ WINDOWS FORMS

Mở BaiTapVeNha_WinForms.sln bằng Visual Studio.
Chuột phải project muốn chạy > Set as Startup Project > F5.

Bài 1: Từ điển Anh-Việt/Việt-Anh, gợi ý gần nhất, Enter/double-click để tra.
Bài 2: ListBox nhiều lựa chọn, đủ 7 chức năng xử lý số.
Bài 3: Danh bạ TreeView A-Z, tự phân loại theo chữ cái đầu của tên.
