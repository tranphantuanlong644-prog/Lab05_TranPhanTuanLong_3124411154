using Microsoft.Data.SqlClient;
namespace ADO_Bai1_QuanLyMonHoc;
/// <summary>
/// Form nạp môn học từ SQL Server và thực hiện thêm, sửa, xóa qua lớp Db dùng tham số SQL.
/// </summary>
public class Form1:Form
{
 TextBox txtMa=new();TextBox txtTen=new();ListView lv=new();
 public Form1(){Text="Quản lý môn học";StartPosition=FormStartPosition.CenterScreen;ClientSize=new Size(900,600);Font=new Font("Tahoma",11);var t=new Label{Text="QUẢN LÝ MÔN HỌC",Font=new Font("Tahoma",18,FontStyle.Bold),ForeColor=Color.DarkBlue,AutoSize=true,Location=new Point(250,20)};Controls.Add(t);Add("Mã môn học:",45,85,txtMa);Add("Tên môn học:",455,85,txtTen);var them=Tao("&Thêm",180);var sua=Tao("&Sửa",320);var xoa=Tao("&Xóa",460);var tai=Tao("Tải &lại",600);lv.SetBounds(45,230,810,300);lv.View=View.Details;lv.GridLines=true;lv.FullRowSelect=true;lv.Columns.Add("Mã môn học",150);lv.Columns.Add("Tên môn học",180);Controls.AddRange(new Control[]{them,sua,xoa,tai,lv});Load+=(_,__)=>Tai();tai.Click+=(_,__)=>Tai();them.Click+=(_,__)=>Them();xoa.Click+=(_,__)=>Xoa();sua.Click+=(_,__)=>Sua();lv.SelectedIndexChanged+=(_,__)=>Chon();}
 void Add(string t,int x,int y,TextBox b){Controls.Add(new Label{Text=t,AutoSize=true,Location=new Point(x,y)});b.SetBounds(x+145,y-4,250,30);Controls.Add(b);}Button Tao(string t,int x)=>new(){Text=t,Location=new Point(x,175),Size=new Size(120,40)};
 void Tai(){try{using var c=new Microsoft.Data.SqlClient.SqlConnection(Db.ConnectionString);using var cmd=new Microsoft.Data.SqlClient.SqlCommand("SELECT * FROM MonHoc",c);c.Open();using var r=cmd.ExecuteReader();lv.Items.Clear();while(r.Read()){var a=new string[r.FieldCount];for(int i=0;i<r.FieldCount;i++)a[i]=r[i].ToString();lv.Items.Add(new ListViewItem(a));}}catch(Exception ex){MessageBox.Show(ex.Message + Environment.NewLine + "Hãy chạy Database/QLSinhVien.sql và sửa ConnectionString trong Db.cs.");}}
 void Them(){if(string.IsNullOrWhiteSpace(txtMa.Text) || string.IsNullOrWhiteSpace(txtTen.Text)){MessageBox.Show("Không được để trống dữ liệu bắt buộc.");return;}try{Db.Execute("INSERT INTO MonHoc(MaMonHoc,TenMonHoc) VALUES(@ma,@ten)",new SqlParameter("@ma",txtMa.Text.Trim()),new SqlParameter("@ten",txtTen.Text.Trim()));MessageBox.Show("Thêm thành công.");Tai();XoaTrang();}catch(Exception ex){MessageBox.Show(ex.Message);}}
 void Xoa(){if(string.IsNullOrWhiteSpace(txtMa.Text)){MessageBox.Show("Khóa không được để trống.");return;}try{Db.Execute("DELETE FROM MonHoc WHERE MaMonHoc=@ma",new SqlParameter("@ma",txtMa.Text.Trim()));MessageBox.Show("Xóa thành công.");Tai();XoaTrang();}catch(Exception ex){MessageBox.Show(ex.Message);}}
 void Sua(){try{if(string.IsNullOrWhiteSpace(txtMa.Text)||string.IsNullOrWhiteSpace(txtTen.Text)){MessageBox.Show("Mã và tên không được trống.");return;}Db.Execute("UPDATE MonHoc SET TenMonHoc=@ten WHERE MaMonHoc=@ma",new SqlParameter("@ten",txtTen.Text.Trim()),new SqlParameter("@ma",txtMa.Text.Trim()));MessageBox.Show("Sửa thành công.");Tai();}catch(Exception ex){MessageBox.Show(ex.Message);}}
 void Chon(){if(lv.SelectedItems.Count==1){var i=lv.SelectedItems[0];txtMa.Text=i.SubItems[0].Text;txtTen.Text=i.SubItems[1].Text;}}
 void XoaTrang(){txtMa.Clear();txtTen.Clear();}
}
