IF DB_ID(N'QLSinhVien') IS NULL CREATE DATABASE QLSinhVien;
GO
USE QLSinhVien;
GO

IF OBJECT_ID('Diem') IS NOT NULL DROP TABLE Diem;
IF OBJECT_ID('SinhVien') IS NOT NULL DROP TABLE SinhVien;
IF OBJECT_ID('MonHoc') IS NOT NULL DROP TABLE MonHoc;
IF OBJECT_ID('Lop') IS NOT NULL DROP TABLE Lop;
IF OBJECT_ID('Khoa') IS NOT NULL DROP TABLE Khoa;
GO

CREATE TABLE Khoa(
    MaKhoa varchar(20) PRIMARY KEY,
    TenKhoa nvarchar(100) NOT NULL
);
CREATE TABLE Lop(
    MaLop varchar(20) PRIMARY KEY,
    TenLop nvarchar(100) NOT NULL,
    MaKhoa varchar(20) NOT NULL REFERENCES Khoa(MaKhoa)
);
CREATE TABLE SinhVien(
    MaSinhVien varchar(20) PRIMARY KEY,
    HoTen nvarchar(100) NOT NULL,
    NgaySinh date NOT NULL,
    MaLop varchar(20) NOT NULL REFERENCES Lop(MaLop)
);
CREATE TABLE MonHoc(
    MaMonHoc varchar(20) PRIMARY KEY,
    TenMonHoc nvarchar(100) NOT NULL
);
CREATE TABLE Diem(
    MaSinhVien varchar(20) NOT NULL REFERENCES SinhVien(MaSinhVien),
    MaMonHoc varchar(20) NOT NULL REFERENCES MonHoc(MaMonHoc),
    Diem decimal(4,2) NOT NULL CHECK(Diem BETWEEN 0 AND 10),
    PRIMARY KEY(MaSinhVien, MaMonHoc)
);

INSERT INTO Khoa VALUES
('CNTT',N'Công nghệ thông tin'),('QTKD',N'Quản trị kinh doanh'),
('KETOAN',N'Kế toán'),('NGOAINGU',N'Ngoại ngữ'),('DULICH',N'Du lịch');
INSERT INTO Lop VALUES
('DCT124C1',N'Đại học CNTT 1','CNTT'),('DCT124C4',N'Đại học CNTT 4','CNTT'),
('QTKD01',N'Quản trị kinh doanh 1','QTKD'),('KT01',N'Kế toán 1','KETOAN'),
('NN01',N'Ngoại ngữ 1','NGOAINGU');
INSERT INTO MonHoc VALUES
('CSHARP',N'Lập trình C#'),('CSDL',N'Cơ sở dữ liệu'),('WF',N'Windows Forms'),
('LINQ',N'Language Integrated Query'),('ADO',N'Công nghệ ADO.NET');
INSERT INTO SinhVien VALUES
('SV001',N'Nguyễn Văn An','2005-01-15','DCT124C1'),
('SV002',N'Trần Minh Châu','2005-03-20','DCT124C1'),
('SV003',N'Lê Quốc Dũng','2005-06-10','DCT124C4'),
('SV004',N'Phạm Thu Hà','2005-09-12','QTKD01'),
('SV005',N'Võ Gia Huy','2005-11-25','KT01');
INSERT INTO Diem VALUES
('SV001','CSHARP',8.5),('SV002','CSDL',7.5),('SV003','WF',9.0),
('SV004','LINQ',8.0),('SV005','ADO',7.0);
GO
