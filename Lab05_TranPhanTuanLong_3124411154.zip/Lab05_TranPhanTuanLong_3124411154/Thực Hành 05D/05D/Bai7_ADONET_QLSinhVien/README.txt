BÀI 7 ADO.NET - QLSinhVien

1. Mở Database/QLSinhVien.sql bằng SQL Server Management Studio và chạy.
2. Mở solution Bai7_ADONET_QLSinhVien.sln.
3. Trong từng project, mở Db.cs và sửa ConnectionString cho đúng SQL Server trên máy.
4. Restore NuGet, Rebuild Solution, chọn project cần chạy làm Startup Project.
5. Mọi câu lệnh SQL đều dùng SqlParameter để tránh lỗi dấu tiếng Việt và SQL injection.
