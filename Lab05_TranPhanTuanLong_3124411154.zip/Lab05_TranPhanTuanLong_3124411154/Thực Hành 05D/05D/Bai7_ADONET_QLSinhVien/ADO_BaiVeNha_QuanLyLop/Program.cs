namespace ADO_BaiVeNha_QuanLyLop;
internal static class Program
{
 [STAThread]
 static void Main()
 {
  ApplicationConfiguration.Initialize();
  Application.Run(new Form1());
 }
}
