using Microsoft.Data.SqlClient;
namespace ADO_NangCao_QuanLyDiem;
/// <summary>
/// Lớp tiện ích dùng chung để mở kết nối và thực thi lệnh SQL có tham số.
/// </summary>
public static class Db
{
 // Sửa Server=... theo SQL Server trên máy. Ví dụ: .\\SQLEXPRESS hoặc (localdb)\\MSSQLLocalDB
 public const string ConnectionString="Server=(localdb)\\MSSQLLocalDB;Database=QLSinhVien;Integrated Security=True;TrustServerCertificate=True";
 public static int Execute(string sql,params SqlParameter[] p){using var c=new SqlConnection(ConnectionString);using var cmd=new SqlCommand(sql,c);cmd.Parameters.AddRange(p);c.Open();return cmd.ExecuteNonQuery();}
}
