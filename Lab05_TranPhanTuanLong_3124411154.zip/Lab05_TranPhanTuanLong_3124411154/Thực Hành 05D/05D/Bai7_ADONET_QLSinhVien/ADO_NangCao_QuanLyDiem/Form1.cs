using Microsoft.Data.SqlClient;
namespace ADO_NangCao_QuanLyDiem;
/// <summary>
/// Form quản lý điểm theo khóa ghép mã sinh viên và mã môn; kiểm tra thang điểm trước khi gửi SQL.
/// </summary>
public class Form1:Form
{
 TextBox sv=new(),mon=new(),diem=new();ListView lv=new();
 public Form1(){Text="Quản lý điểm";StartPosition=FormStartPosition.CenterScreen;ClientSize=new Size(820,560);Font=new Font("Tahoma",11);var title=new Label{Text="QUẢN LÝ ĐIỂM",Font=new Font("Tahoma",18,FontStyle.Bold),ForeColor=Color.DarkBlue,AutoSize=true,Location=new Point(290,18)};Controls.Add(title);Add("Mã sinh viên:",45,90,sv);Add("Mã môn học:",430,90,mon);Add("Điểm:",45,140,diem);Button them=Tao("Thêm",210),sua=Tao("Sửa",350),xoa=Tao("Xóa",490);Controls.AddRange(new Control[]{them,sua,xoa});lv.SetBounds(45,225,725,260);lv.View=View.Details;lv.FullRowSelect=true;lv.GridLines=true;lv.Columns.Add("MSSV",220);lv.Columns.Add("Mã môn",220);lv.Columns.Add("Điểm",180);Controls.Add(lv);Load+=(_,__)=>Tai();them.Click+=(_,__)=>Them();sua.Click+=(_,__)=>Sua();xoa.Click+=(_,__)=>Xoa();}
 void Add(string t,int x,int y,TextBox b){Controls.Add(new Label{Text=t,AutoSize=true,Location=new Point(x,y)});b.SetBounds(x+135,y-4,225,30);Controls.Add(b);}Button Tao(string t,int x)=>new(){Text=t,Location=new Point(x,170),Size=new Size(120,40)};
 bool Kiem(out decimal d){d=0;if(sv.Text.Trim()==""||mon.Text.Trim()==""||!decimal.TryParse(diem.Text,out d)||d<0||d>10){MessageBox.Show("Nhập MSSV, mã môn và điểm từ 0 đến 10.");return false;}return true;}
 void Tai(){try{using var c=new SqlConnection(Db.ConnectionString);using var cmd=new SqlCommand("SELECT MaSinhVien,MaMonHoc,Diem FROM Diem",c);c.Open();using var r=cmd.ExecuteReader();lv.Items.Clear();while(r.Read())lv.Items.Add(new ListViewItem(new[]{r[0].ToString(),r[1].ToString(),r[2].ToString()}));}catch(Exception ex){MessageBox.Show(ex.Message);}}
 void Them(){if(!Kiem(out decimal d))return;try{Db.Execute("INSERT INTO Diem VALUES(@sv,@mon,@d)",new("@sv",sv.Text.Trim()),new("@mon",mon.Text.Trim()),new("@d",d));Tai();}catch(Exception ex){MessageBox.Show(ex.Message);}}
 void Xoa(){if(sv.Text.Trim()==""||mon.Text.Trim()==""){MessageBox.Show("MSSV và mã môn bắt buộc.");return;}try{Db.Execute("DELETE FROM Diem WHERE MaSinhVien=@sv AND MaMonHoc=@mon",new("@sv",sv.Text.Trim()),new("@mon",mon.Text.Trim()));Tai();}catch(Exception ex){MessageBox.Show(ex.Message);}}
 void Sua(){if(!Kiem(out decimal d))return;try{Db.Execute("UPDATE Diem SET Diem=@d WHERE MaSinhVien=@sv AND MaMonHoc=@mon",new("@d",d),new("@sv",sv.Text.Trim()),new("@mon",mon.Text.Trim()));Tai();}catch(Exception ex){MessageBox.Show(ex.Message);}}
}