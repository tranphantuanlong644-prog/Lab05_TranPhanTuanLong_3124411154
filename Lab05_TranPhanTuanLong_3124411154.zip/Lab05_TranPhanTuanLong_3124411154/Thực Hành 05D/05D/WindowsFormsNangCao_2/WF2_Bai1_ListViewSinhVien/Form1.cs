namespace WF2_Bai1_ListViewSinhVien;
/// <summary>
/// ListView giữ danh sách sinh viên; kiểm tra mã trùng trước khi thêm và dùng chung xử lý xóa cho menu chuột phải.
/// </summary>
public class Form1:Form
{
 TextBox txtMa=new(),txtTen=new();ComboBox cboDT=new();ListView lv=new();Button btnThem=new(),btnSua=new(),btnXoa=new(),btnThoat=new();ContextMenuStrip menu=new();
 public Form1(){Text="Quản lý sinh viên bằng ListView";StartPosition=FormStartPosition.CenterScreen;ClientSize=new Size(850,570);Font=new Font("Tahoma",11);FormBorderStyle=FormBorderStyle.FixedSingle;MaximizeBox=false;
 var title=new Label{Text="QUẢN LÝ SINH VIÊN",Font=new Font("Tahoma",18,FontStyle.Bold),ForeColor=Color.DarkBlue,AutoSize=true,Location=new Point(250,20)};
 AddLabel("Mã sinh viên:",40,90);txtMa.SetBounds(170,86,230,30);AddLabel("Họ tên:",40,135);txtTen.SetBounds(170,131,230,30);AddLabel("Dân tộc:",440,90);cboDT.SetBounds(540,86,240,30);cboDT.DropDownStyle=ComboBoxStyle.DropDownList;
 btnThem=Tao("&Thêm",440,130);btnSua=Tao("&Sửa",560,130);btnXoa=Tao("&Xóa",680,130);btnThoat=Tao("Th&oát",680,500);
 lv.SetBounds(40,205,740,270);lv.View=View.Details;lv.FullRowSelect=true;lv.GridLines=true;lv.MultiSelect=true;lv.Columns.Add("MSSV",160);lv.Columns.Add("Họ tên",350);lv.Columns.Add("Dân tộc",200);
 var xoaMenu=new ToolStripMenuItem("Xóa sinh viên đang chọn");menu.Items.Add(xoaMenu);lv.ContextMenuStrip=menu;
 Controls.AddRange(new Control[]{title,txtMa,txtTen,cboDT,btnThem,btnSua,btnXoa,btnThoat,lv});Load+=(_,__)=>{cboDT.Items.AddRange(new[]{"Kinh","Hoa","K’Me","H’Mong","Khác"});cboDT.SelectedIndex=0;};
 btnThem.Click+=(_,__)=>Them();btnSua.Click+=(_,__)=>Sua();btnXoa.Click+=(_,__)=>Xoa();xoaMenu.Click+=(_,__)=>Xoa();lv.SelectedIndexChanged+=(_,__)=>Chon();btnThoat.Click+=(_,__)=>Close();FormClosing+=XacNhanThoat;}
 void AddLabel(string t,int x,int y)=>Controls.Add(new Label{Text=t,AutoSize=true,Location=new Point(x,y)});Button Tao(string t,int x,int y){var b=new Button{Text=t,Location=new Point(x,y),Size=new Size(100,38)};return b;}
 bool HopLe()=>txtMa.Text.Trim()!=""&&txtTen.Text.Trim()!="";bool Trung(string m)=>lv.Items.Cast<ListViewItem>().Any(x=>x.Text.Equals(m,StringComparison.OrdinalIgnoreCase));
 void Them(){if(!HopLe()){MessageBox.Show("Mã và họ tên không được trống.");return;}if(Trung(txtMa.Text.Trim())){MessageBox.Show("Mã sinh viên đã tồn tại.");return;}lv.Items.Add(new ListViewItem(new[]{txtMa.Text.Trim(),txtTen.Text.Trim(),cboDT.Text}));XoaTrang();}
 void Sua(){if(lv.SelectedItems.Count!=1){MessageBox.Show("Chọn đúng một sinh viên để sửa.");return;}if(txtTen.Text.Trim()==""){MessageBox.Show("Họ tên không được trống.");return;}var i=lv.SelectedItems[0];i.SubItems[1].Text=txtTen.Text.Trim();i.SubItems[2].Text=cboDT.Text;}
 void Xoa(){if(lv.SelectedItems.Count==0){MessageBox.Show("Chưa chọn sinh viên.");return;}if(MessageBox.Show("Xóa các sinh viên đang chọn?","Xác nhận",MessageBoxButtons.YesNo)==DialogResult.Yes)foreach(ListViewItem i in lv.SelectedItems)i.Remove();XoaTrang();}
 void Chon(){if(lv.SelectedItems.Count==1){var i=lv.SelectedItems[0];txtMa.Text=i.Text;txtMa.Enabled=false;txtTen.Text=i.SubItems[1].Text;cboDT.Text=i.SubItems[2].Text;}else txtMa.Enabled=true;}
 void XoaTrang(){txtMa.Enabled=true;txtMa.Clear();txtTen.Clear();txtMa.Focus();}
 private void XacNhanThoat(object s,FormClosingEventArgs e){if(MessageBox.Show("Bạn có chắc muốn thoát?","Xác nhận",MessageBoxButtons.YesNo,MessageBoxIcon.Question)==DialogResult.No)e.Cancel=true;}
}