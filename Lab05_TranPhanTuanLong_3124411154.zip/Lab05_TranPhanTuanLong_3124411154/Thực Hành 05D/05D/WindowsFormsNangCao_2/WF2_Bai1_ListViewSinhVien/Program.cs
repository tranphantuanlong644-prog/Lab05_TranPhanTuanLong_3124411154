namespace WF2_Bai1_ListViewSinhVien;
internal static class Program
{
 [STAThread]
 static void Main()
 {
  ApplicationConfiguration.Initialize();
  Application.Run(new Form1());
 }
}
