namespace WF2_BaiVeNha_DemNguoc;
internal static class Program
{
 [STAThread]
 static void Main()
 {
  ApplicationConfiguration.Initialize();
  Application.Run(new Form1());
 }
}
