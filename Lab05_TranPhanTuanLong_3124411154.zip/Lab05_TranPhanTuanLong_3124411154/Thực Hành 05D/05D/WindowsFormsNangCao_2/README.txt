WINDOWS FORMS NÂNG CAO 2

Mở WindowsFormsNangCao_2.sln. Chuột phải project cần chạy > Set as Startup Project > F5.
Mỗi bài là một project và mỗi form nằm trong file riêng.
