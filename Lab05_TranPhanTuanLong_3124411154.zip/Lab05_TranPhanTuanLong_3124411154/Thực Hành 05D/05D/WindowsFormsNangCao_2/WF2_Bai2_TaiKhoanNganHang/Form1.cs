namespace WF2_Bai2_TaiKhoanNganHang;
/// <summary>
/// Trạng thái thêm/hủy điều khiển nút và ô nhập; sau khi thay đổi, cập nhật lại STT và tổng tiền.
/// </summary>
public class Form1:Form
{
 TextBox txtSTK=new(),txtTen=new(),txtDC=new(),txtTien=new();ListView lv=new();Button btnThem=new(),btnLuu=new(),btnXoa=new(),btnThoat=new();Label lblTong=new();bool dangThem=false;
 public Form1(){Text="Quản lý tài khoản ngân hàng";StartPosition=FormStartPosition.CenterScreen;ClientSize=new Size(930,650);Font=new Font("Tahoma",11);FormBorderStyle=FormBorderStyle.FixedSingle;MaximizeBox=false;
 var title=new Label{Text="QUẢN LÝ TÀI KHOẢN NGÂN HÀNG",Font=new Font("Tahoma",18,FontStyle.Bold),ForeColor=Color.DarkBlue,AutoSize=true,Location=new Point(220,18)};Controls.Add(title);
 Add("Số tài khoản:",45,85,txtSTK);Add("Tên khách hàng:",45,130,txtTen);Add("Địa chỉ:",470,85,txtDC);Add("Số tiền:",470,130,txtTien);
 btnThem=Tao("&Thêm",180);btnLuu=Tao("&Lưu",310);btnXoa=Tao("&Xóa",440);btnThoat=Tao("Th&oát",700);btnLuu.Enabled=false;btnXoa.Enabled=false;
 lv.SetBounds(45,225,835,310);lv.View=View.Details;lv.FullRowSelect=true;lv.GridLines=true;lv.Columns.Add("STT",60);lv.Columns.Add("Số TK",150);lv.Columns.Add("Khách hàng",240);lv.Columns.Add("Địa chỉ",230);lv.Columns.Add("Số tiền",140);
 lblTong.SetBounds(45,555,500,30);lblTong.Font=new Font("Tahoma",11,FontStyle.Bold);Controls.AddRange(new Control[]{btnThem,btnLuu,btnXoa,btnThoat,lv,lblTong});CapNhatUI();
 btnThem.Click+=(_,__)=>BatDauHoacHuy();btnLuu.Click+=(_,__)=>Luu();btnXoa.Click+=(_,__)=>Xoa();lv.SelectedIndexChanged+=(_,__)=>Chon();btnThoat.Click+=(_,__)=>Close();FormClosing+=XacNhanThoat;}
 void Add(string t,int x,int y,TextBox tb){Controls.Add(new Label{Text=t,AutoSize=true,Location=new Point(x,y)});tb.SetBounds(x+150,y-4,230,30);Controls.Add(tb);}Button Tao(string t,int x){var b=new Button{Text=t,Location=new Point(x,170),Size=new Size(110,38)};return b;}
 void BatDauHoacHuy(){dangThem=!dangThem;btnThem.Text=dangThem?"&Hủy":"&Thêm";btnLuu.Enabled=dangThem;btnXoa.Enabled=false;txtSTK.Enabled=dangThem;XoaTrang();if(dangThem)txtSTK.Focus();}
 void Luu(){if(new[]{txtSTK.Text,txtTen.Text,txtDC.Text,txtTien.Text}.Any(string.IsNullOrWhiteSpace)||!decimal.TryParse(txtTien.Text,out decimal tien)||tien<0){MessageBox.Show("Nhập đầy đủ và số tiền hợp lệ.");return;}if(lv.Items.Cast<ListViewItem>().Any(x=>x.SubItems[1].Text==txtSTK.Text.Trim())){MessageBox.Show("Số tài khoản đã tồn tại.");return;}lv.Items.Add(new ListViewItem(new[]{"",txtSTK.Text.Trim(),txtTen.Text.Trim(),txtDC.Text.Trim(),tien.ToString("N0")}));DanhSTT();TinhTong();BatDauHoacHuy();}
 void Xoa(){if(lv.SelectedItems.Count==0)return;if(MessageBox.Show("Xóa tài khoản đang chọn?","Xác nhận",MessageBoxButtons.YesNo)==DialogResult.Yes)lv.SelectedItems[0].Remove();DanhSTT();TinhTong();XoaTrang();}
 void Chon(){btnXoa.Enabled=lv.SelectedItems.Count==1&&!dangThem;if(lv.SelectedItems.Count==1){var i=lv.SelectedItems[0];txtSTK.Text=i.SubItems[1].Text;txtTen.Text=i.SubItems[2].Text;txtDC.Text=i.SubItems[3].Text;txtTien.Text=i.SubItems[4].Text;}}
 void DanhSTT(){for(int i=0;i<lv.Items.Count;i++)lv.Items[i].Text=(i+1).ToString();}void TinhTong(){decimal t=lv.Items.Cast<ListViewItem>().Sum(x=>decimal.Parse(x.SubItems[4].Text,System.Globalization.NumberStyles.Number));lblTong.Text=$"Tổng tiền: {t:N0} đồng";}
 void XoaTrang(){txtSTK.Clear();txtTen.Clear();txtDC.Clear();txtTien.Clear();}void CapNhatUI(){txtSTK.Enabled=false;lblTong.Text="Tổng tiền: 0 đồng";}
 private void XacNhanThoat(object s,FormClosingEventArgs e){if(MessageBox.Show("Bạn có chắc muốn thoát?","Xác nhận",MessageBoxButtons.YesNo)==DialogResult.No)e.Cancel=true;}
}