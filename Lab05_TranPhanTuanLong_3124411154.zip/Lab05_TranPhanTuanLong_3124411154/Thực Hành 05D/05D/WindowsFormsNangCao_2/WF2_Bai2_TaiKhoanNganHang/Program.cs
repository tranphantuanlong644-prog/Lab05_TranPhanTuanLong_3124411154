namespace WF2_Bai2_TaiKhoanNganHang;
internal static class Program
{
 [STAThread]
 static void Main()
 {
  ApplicationConfiguration.Initialize();
  Application.Run(new Form1());
 }
}
