using System.Diagnostics;
namespace WF2_BaiVeNha_FormMain;
/// <summary>
/// Menu mở file thực thi của từng bài theo thư mục solution và báo cách xử lý nếu project chưa được build.
/// </summary>
public class Form1 : Form
{
    public Form1()
    {
        Text = "Form chính - Windows Forms nâng cao 2";
        StartPosition = FormStartPosition.CenterScreen;
        ClientSize = new Size(780, 470);
        Font = new Font("Tahoma", 11);

        MenuStrip menu = new();
        ToolStripMenuItem baiTap = new("Bài tập");
        Them(baiTap, "Quản lý sinh viên ListView", "WF2_Bai1_ListViewSinhVien");
        Them(baiTap, "Quản lý tài khoản ngân hàng", "WF2_Bai2_TaiKhoanNganHang");
        Them(baiTap, "Quản lý học viên lớp A/B", "WF2_NangCao_QuanLyHocVien");
        Them(baiTap, "Đếm ngược thời gian", "WF2_BaiVeNha_DemNguoc");

        ToolStripMenuItem heThong = new("Hệ thống");
        ToolStripMenuItem ketThuc = new("Kết thúc");
        ketThuc.Click += (_, _) => Close();
        heThong.DropDownItems.Add(ketThuc);
        menu.Items.AddRange(new ToolStripItem[] { baiTap, heThong });
        MainMenuStrip = menu;
        Controls.Add(menu);

        Controls.Add(new Label
        {
            Text = "FORM CHÍNH WINDOWS FORMS NÂNG CAO 2\nChọn bài tập từ MenuStrip",
            TextAlign = ContentAlignment.MiddleCenter,
            Dock = DockStyle.Fill,
            Font = new Font("Tahoma", 20, FontStyle.Bold),
            ForeColor = Color.DarkBlue
        });

        FormClosing += (s, e) =>
        {
            if (MessageBox.Show("Bạn có chắc muốn thoát?", "Xác nhận",
                MessageBoxButtons.YesNo) == DialogResult.No) e.Cancel = true;
        };
    }

    private void Them(ToolStripMenuItem cha, string text, string project)
    {
        ToolStripMenuItem item = new(text);
        item.Click += (_, _) => MoProject(project);
        cha.DropDownItems.Add(item);
    }

    private void MoProject(string project)
    {
        string solutionRoot = Path.GetFullPath(Path.Combine(
            AppContext.BaseDirectory, "..", "..", "..", ".."));
        string exe = Path.Combine(solutionRoot, project, "bin", "Debug",
            "net8.0-windows", project + ".exe");

        if (!File.Exists(exe))
        {
            MessageBox.Show(
                $"Chưa tìm thấy file chạy của {project}.\n" +
                "Hãy chọn Build > Rebuild Solution trước khi mở từ Form Main.",
                "Chưa build project",
                MessageBoxButtons.OK,
                MessageBoxIcon.Warning);
            return;
        }

        Process.Start(new ProcessStartInfo(exe) { UseShellExecute = true });
    }
}
