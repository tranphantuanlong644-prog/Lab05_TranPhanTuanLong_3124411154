namespace WF2_NangCao_QuanLyHocVien;
/// <summary>
/// Hai ListBox quản lý lớp A và B; sao chép danh sách chọn trước khi chuyển hoặc xóa để giữ nguyên tập duyệt.
/// </summary>
public class Form1:Form
{
 ListBox a=new(),b=new();
 public Form1(){Text="Quản lý học viên lớp A và B";StartPosition=FormStartPosition.CenterScreen;ClientSize=new Size(800,520);Font=new Font("Tahoma",11);var menu=new MenuStrip();var he=new ToolStripMenuItem("Hệ thống");var kt=new ToolStripMenuItem("Kết thúc");he.DropDownItems.Add(kt);var cn=new ToolStripMenuItem("Cập nhật");var nhap=new ToolStripMenuItem("Nhập học viên mới");var xoa=new ToolStripMenuItem("Xóa học viên");var sangA=new ToolStripMenuItem("Chuyển sang lớp A");var sangB=new ToolStripMenuItem("Chuyển sang lớp B");cn.DropDownItems.AddRange(new ToolStripItem[]{nhap,xoa,sangA,sangB});menu.Items.AddRange(new ToolStripItem[]{he,cn});MainMenuStrip=menu;Controls.Add(menu);
 Controls.Add(new Label{Text="LỚP A",Font=new Font("Tahoma",14,FontStyle.Bold),AutoSize=true,Location=new Point(170,65)});Controls.Add(new Label{Text="LỚP B",Font=new Font("Tahoma",14,FontStyle.Bold),AutoSize=true,Location=new Point(555,65)});a.SetBounds(55,105,310,340);b.SetBounds(430,105,310,340);a.SelectionMode=b.SelectionMode=SelectionMode.MultiExtended;Controls.AddRange(new Control[]{a,b});
 a.Items.AddRange(new[]{"Nguyễn Văn An","Trần Minh Châu","Lê Quốc Dũng"});b.Items.AddRange(new[]{"Phạm Thu Hà","Võ Gia Huy","Đinh Thị Lan"});kt.Click+=(_,__)=>Close();nhap.Click+=(_,__)=>new FormNhap(a,b).ShowDialog(this);xoa.Click+=(_,__)=>{XoaChon(a);XoaChon(b);};sangA.Click+=(_,__)=>Chuyen(b,a);sangB.Click+=(_,__)=>Chuyen(a,b);FormClosing+=XacNhan;}
 void Chuyen(ListBox nguon,ListBox dich){if(nguon.SelectedItems.Count==0){MessageBox.Show("Vui lòng chọn học viên trước.");return;}var ds=nguon.SelectedItems.Cast<object>().ToList();foreach(var x in ds){if(!dich.Items.Contains(x))dich.Items.Add(x);nguon.Items.Remove(x);}}
 void XoaChon(ListBox l){var ds=l.SelectedItems.Cast<object>().ToList();foreach(var x in ds)l.Items.Remove(x);}void XacNhan(object s,FormClosingEventArgs e){if(MessageBox.Show("Bạn có chắc muốn kết thúc?","Xác nhận",MessageBoxButtons.YesNo)==DialogResult.No)e.Cancel=true;}
}