﻿BÀI THỰC HÀNH WINDOWS FORMS NÂNG CAO 5C VÀ 5D
Sinh viên: Trần Phan Tuấn Long - 3124411154

CẤU TRÚC
- Thực Hành 05C: 6 project Windows Forms và báo cáo 5C.
- Thực Hành 05D: 5 project Windows Forms nâng cao, 4 project ADO.NET, script cơ sở dữ liệu và báo cáo 5D.

CÁCH MỞ VÀ CHẠY
- Mở file .sln hoặc .csproj của bài cần làm trong Visual Studio, chọn project làm Startup Project rồi nhấn F5.
- Các project dùng .NET 8 Windows Forms; project Ước Số dùng .NET 10 Windows Forms.
- Với ADO.NET, chạy Database/QLSinhVien.sql trên SQL Server, sau đó sửa Server trong Db.cs của project cần chạy.
- Mã xử lý chính trong Form1.cs có chú thích tóm tắt luồng dữ liệu và các quy tắc quan trọng.

BÁO CÁO
Hai báo cáo Word gồm trang bìa có họ tên, mã sinh viên; nội dung bài; giải thích cách làm và kết quả kiểm thử. Kết quả ADO.NET được ghi là dự kiến vì cần kết nối SQL Server trên máy chạy.
